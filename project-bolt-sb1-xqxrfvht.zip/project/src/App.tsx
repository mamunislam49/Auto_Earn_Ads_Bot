import React, { useState, useEffect, useCallback } from 'react';
import { Gamepad2, Users, Gift, ShoppingCart, Trophy, Settings, Zap, Star, Coins } from 'lucide-react';
import GameScreen from './components/GameScreen';
import FriendsScreen from './components/FriendsScreen';
import StampsScreen from './components/StampsScreen';
import ShopScreen from './components/ShopScreen';
import LeaderboardScreen from './components/LeaderboardScreen';
import TasksScreen from './components/TasksScreen';
import { GameProvider } from './contexts/GameContext';

type Screen = 'game' | 'friends' | 'stamps' | 'shop' | 'leaderboard' | 'tasks';

function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>('game');

  const navigationItems = [
    { id: 'game' as Screen, icon: Gamepad2, label: 'Game' },
    { id: 'friends' as Screen, icon: Users, label: 'Friends' },
    { id: 'stamps' as Screen, icon: Star, label: 'Stamps' },
    { id: 'shop' as Screen, icon: ShoppingCart, label: 'Shop' },
    { id: 'leaderboard' as Screen, icon: Trophy, label: 'Top' },
    { id: 'tasks' as Screen, icon: Gift, label: 'Tasks' },
  ];

  const renderScreen = () => {
    switch (activeScreen) {
      case 'game':
        return <GameScreen />;
      case 'friends':
        return <FriendsScreen />;
      case 'stamps':
        return <StampsScreen />;
      case 'shop':
        return <ShopScreen />;
      case 'leaderboard':
        return <LeaderboardScreen />;
      case 'tasks':
        return <TasksScreen />;
      default:
        return <GameScreen />;
    }
  };

  return (
    <GameProvider>
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white">
        <div className="max-w-md mx-auto min-h-screen bg-gradient-to-br from-purple-800/20 to-blue-800/20 backdrop-blur-sm border-l border-r border-white/10">
          {/* Header */}
          <div className="sticky top-0 z-50 bg-gradient-to-r from-purple-800/80 to-blue-800/80 backdrop-blur-lg border-b border-white/10 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-2xl">
                  🐹
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                    Hamster Kombat
                  </h1>
                  <p className="text-xs text-gray-300">Tap to Earn</p>
                </div>
              </div>
              <button className="p-2 bg-white/10 rounded-xl hover:bg-white/20 transition-colors">
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Screen Content */}
          <div className="pb-20">
            {renderScreen()}
          </div>

          {/* Bottom Navigation */}
          <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-gradient-to-r from-purple-800/90 to-blue-800/90 backdrop-blur-lg border-t border-white/10">
            <div className="grid grid-cols-6 p-2">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeScreen === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveScreen(item.id)}
                    className={`p-3 rounded-xl transition-all duration-200 ${
                      isActive
                        ? 'bg-gradient-to-r from-yellow-400/20 to-orange-500/20 text-yellow-400 scale-105'
                        : 'text-gray-400 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <Icon className="w-5 h-5 mx-auto mb-1" />
                    <p className="text-xs font-medium">{item.label}</p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </GameProvider>
  );
}

export default App;