import React from 'react';
import { useGame } from '../contexts/GameContext';
import { ShoppingCart, ArrowUp, Zap, Battery, TrendingUp } from 'lucide-react';

const ShopScreen: React.FC = () => {
  const { upgrades, purchaseUpgrade, stats } = useGame();

  const getUpgradeIcon = (id: string) => {
    switch (id) {
      case '1': return '👆';
      case '2': return '🔋';
      case '3': return '⚡';
      default: return '🔧';
    }
  };

  const canAfford = (cost: number) => stats.coins >= cost;

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl">
          🛒
        </div>
        <h2 className="text-2xl font-bold bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
          Upgrade Shop
        </h2>
        <p className="text-gray-300">Boost your hamster's power!</p>
      </div>

      {/* Current Coins */}
      <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-2xl p-4 text-center">
        <div className="flex items-center justify-center space-x-2 mb-2">
          <span className="text-2xl">💰</span>
          <span className="text-2xl font-bold text-yellow-400">{stats.coins.toLocaleString()}</span>
        </div>
        <p className="text-sm text-gray-300">Available Coins</p>
      </div>

      {/* Current Stats */}
      <div className="bg-gradient-to-r from-purple-800/30 to-blue-800/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 text-center">Current Stats</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl mb-1">👆</div>
            <p className="text-lg font-bold text-yellow-400">{stats.tapPower}</p>
            <p className="text-xs text-gray-300">Tap Power</p>
          </div>
          <div className="text-center">
            <div className="text-2xl mb-1">🔋</div>
            <p className="text-lg font-bold text-blue-400">{stats.maxEnergy}</p>
            <p className="text-xs text-gray-300">Max Energy</p>
          </div>
          <div className="text-center">
            <div className="text-2xl mb-1">⚡</div>
            <p className="text-lg font-bold text-green-400">{stats.energyRecharge}/s</p>
            <p className="text-xs text-gray-300">Recharge</p>
          </div>
        </div>
      </div>

      {/* Upgrades */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-200">Available Upgrades</h3>
        <div className="space-y-4">
          {upgrades.map((upgrade) => (
            <div
              key={upgrade.id}
              className={`bg-gradient-to-r from-gray-800/50 to-gray-700/50 backdrop-blur-sm border ${
                canAfford(upgrade.cost) ? 'border-green-500/30' : 'border-white/10'
              } rounded-2xl p-4 transition-all duration-200`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-2xl">
                    {getUpgradeIcon(upgrade.id)}
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-200">{upgrade.name}</h4>
                    <p className="text-sm text-gray-400">{upgrade.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-yellow-400">{upgrade.cost.toLocaleString()}</p>
                  <p className="text-xs text-gray-400">coins</p>
                </div>
              </div>

              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-green-400">{upgrade.effect}</span>
                </div>
                <div className="text-sm text-gray-300">
                  Level {upgrade.level} / {upgrade.maxLevel}
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-gray-700/50 rounded-full h-2 mb-4 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-blue-400 to-purple-500 h-full transition-all duration-300 ease-out rounded-full"
                  style={{ width: `${(upgrade.level / upgrade.maxLevel) * 100}%` }}
                />
              </div>

              <button
                onClick={() => purchaseUpgrade(upgrade.id)}
                disabled={!canAfford(upgrade.cost) || upgrade.level >= upgrade.maxLevel}
                className={`w-full py-3 px-4 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center space-x-2 ${
                  upgrade.level >= upgrade.maxLevel
                    ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                    : canAfford(upgrade.cost)
                    ? 'bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white hover:scale-105'
                    : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                }`}
              >
                {upgrade.level >= upgrade.maxLevel ? (
                  <>
                    <span>✓ Maxed Out</span>
                  </>
                ) : canAfford(upgrade.cost) ? (
                  <>
                    <ArrowUp className="w-4 h-4" />
                    <span>Upgrade Now</span>
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-4 h-4" />
                    <span>Not Enough Coins</span>
                  </>
                )}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Upgrade Tips */}
      <div className="bg-gradient-to-r from-purple-800/30 to-blue-800/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
          <span className="text-2xl">💡</span>
          <span>Upgrade Strategy</span>
        </h3>
        <div className="space-y-2 text-sm text-gray-300">
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span><strong>Tap Power:</strong> More coins per tap, great for active play</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span><strong>Energy Capacity:</strong> Tap longer without waiting</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span><strong>Recharge Rate:</strong> Get back to tapping faster</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Balance all upgrades for maximum efficiency</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShopScreen;