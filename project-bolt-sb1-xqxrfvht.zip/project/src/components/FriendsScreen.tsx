import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { Users, Share2, Gift, Copy, UserPlus, Star } from 'lucide-react';

const FriendsScreen: React.FC = () => {
  const { friends, inviteFriend, stats } = useGame();
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteLink] = useState('https://t.me/HamsterKombatBot?start=ref_12345');

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(inviteLink);
      alert('Invite link copied to clipboard!');
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const handleShareLink = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join me in Hamster Kombat!',
          text: 'Tap to earn coins and build your crypto empire!',
          url: inviteLink,
        });
      } catch (err) {
        console.error('Error sharing: ', err);
      }
    } else {
      handleCopyLink();
    }
  };

  const simulateInvite = () => {
    const randomNames = ['CryptoExplorer', 'TapMaster', 'CoinCollector', 'HamsterFan'];
    const randomAvatars = ['👨‍💼', '👩‍🚀', '👨‍🎨', '👩‍💻', '🧑‍🚒'];
    
    const newFriend = {
      name: randomNames[Math.floor(Math.random() * randomNames.length)],
      avatar: randomAvatars[Math.floor(Math.random() * randomAvatars.length)],
      coins: Math.floor(Math.random() * 10000) + 5000,
      referralBonus: 1000,
    };

    inviteFriend(newFriend);
    setShowInviteModal(false);
  };

  const totalReferralBonus = friends.reduce((sum, friend) => sum + friend.referralBonus, 0);

  return (
    <div className="p-4 space-y-6">
      {/* Header Stats */}
      <div className="text-center space-y-2">
        <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl">
          👥
        </div>
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          Friends Network
        </h2>
        <p className="text-gray-300">Build your team and earn together!</p>
      </div>

      {/* Referral Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm border border-blue-500/30 rounded-2xl p-4 text-center">
          <Users className="w-6 h-6 mx-auto mb-2 text-blue-400" />
          <p className="text-2xl font-bold text-blue-400">{friends.length}</p>
          <p className="text-xs text-gray-300">Friends</p>
        </div>
        
        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-2xl p-4 text-center">
          <Gift className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-2xl font-bold text-yellow-400">{totalReferralBonus.toLocaleString()}</p>
          <p className="text-xs text-gray-300">Earned</p>
        </div>
      </div>

      {/* Invite Buttons */}
      <div className="space-y-3">
        <button
          onClick={() => setShowInviteModal(true)}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-4 px-6 rounded-2xl transition-all duration-200 transform hover:scale-105 flex items-center justify-center space-x-2"
        >
          <UserPlus className="w-5 h-5" />
          <span>Invite Friends</span>
        </button>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleCopyLink}
            className="bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <Copy className="w-4 h-4" />
            <span className="text-sm">Copy Link</span>
          </button>
          
          <button
            onClick={handleShareLink}
            className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <Share2 className="w-4 h-4" />
            <span className="text-sm">Share</span>
          </button>
        </div>
      </div>

      {/* Referral Benefits */}
      <div className="bg-gradient-to-r from-purple-800/30 to-blue-800/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
          <Star className="w-5 h-5 text-yellow-400" />
          <span>Referral Benefits</span>
        </h3>
        <div className="space-y-2 text-sm text-gray-300">
          <div className="flex justify-between">
            <span>• Invite a friend</span>
            <span className="text-yellow-400 font-semibold">+1,000 coins</span>
          </div>
          <div className="flex justify-between">
            <span>• Friend reaches Level 5</span>
            <span className="text-yellow-400 font-semibold">+5,000 coins</span>
          </div>
          <div className="flex justify-between">
            <span>• 10% of friend's earnings</span>
            <span className="text-yellow-400 font-semibold">Forever</span>
          </div>
        </div>
      </div>

      {/* Friends List */}
      {friends.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-200">Your Network</h3>
          <div className="space-y-3">
            {friends.map((friend) => (
              <div
                key={friend.id}
                className="bg-gradient-to-r from-gray-800/50 to-gray-700/50 backdrop-blur-sm border border-white/10 rounded-2xl p-4 flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-2xl">
                    {friend.avatar}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-200">{friend.name}</p>
                    <p className="text-sm text-gray-400">{friend.coins.toLocaleString()} coins</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-yellow-400 font-semibold">+{friend.referralBonus}</p>
                  <p className="text-xs text-gray-400">bonus</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {friends.length === 0 && (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
            👥
          </div>
          <p className="text-gray-400 mb-4">No friends invited yet</p>
          <p className="text-sm text-gray-500">Start building your network to earn more!</p>
        </div>
      )}

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-gradient-to-r from-gray-800 to-gray-900 border border-white/20 rounded-2xl p-6 max-w-sm w-full">
            <h3 className="text-xl font-bold text-center mb-4">Invite a Friend</h3>
            <p className="text-gray-300 text-center mb-6">
              Share your referral link and earn 1,000 coins for each friend who joins!
            </p>
            
            <div className="space-y-3">
              <button
                onClick={simulateInvite}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-200"
              >
                Simulate Invite (Demo)
              </button>
              
              <button
                onClick={handleShareLink}
                className="w-full bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-200 flex items-center justify-center space-x-2"
              >
                <Share2 className="w-4 h-4" />
                <span>Share Real Link</span>
              </button>
              
              <button
                onClick={() => setShowInviteModal(false)}
                className="w-full bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-200"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FriendsScreen;