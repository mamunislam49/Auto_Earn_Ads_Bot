import React, { useState, useEffect } from 'react';
import { useGame } from '../contexts/GameContext';
import { Zap, Coins, TrendingUp, Star } from 'lucide-react';

const GameScreen: React.FC = () => {
  const { stats, tap } = useGame();
  const [tapEffects, setTapEffects] = useState<Array<{ id: number; x: number; y: number }>>([]);
  const [hamsterScale, setHamsterScale] = useState(1);

  const handleTap = (e: React.MouseEvent) => {
    if (stats.energy <= 0) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Add tap effect
    const effectId = Date.now();
    setTapEffects(prev => [...prev, { id: effectId, x, y }]);

    // Remove effect after animation
    setTimeout(() => {
      setTapEffects(prev => prev.filter(effect => effect.id !== effectId));
    }, 1000);

    // Scale animation
    setHamsterScale(1.1);
    setTimeout(() => setHamsterScale(1), 100);

    tap();
  };

  const energyPercentage = (stats.energy / stats.maxEnergy) * 100;
  const experiencePercentage = (stats.experience / stats.experienceToNext) * 100;

  return (
    <div className="p-4 space-y-6">
      {/* Stats Header */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-2xl p-4 text-center">
          <Coins className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-2xl font-bold text-yellow-400">{stats.coins.toLocaleString()}</p>
          <p className="text-xs text-gray-300">Coins</p>
        </div>
        
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm border border-blue-500/30 rounded-2xl p-4 text-center">
          <TrendingUp className="w-6 h-6 mx-auto mb-2 text-blue-400" />
          <p className="text-2xl font-bold text-blue-400">Level {stats.level}</p>
          <p className="text-xs text-gray-300">Experience</p>
        </div>
        
        <div className="bg-gradient-to-r from-green-500/20 to-teal-500/20 backdrop-blur-sm border border-green-500/30 rounded-2xl p-4 text-center">
          <Star className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold text-green-400">{stats.friends}</p>
          <p className="text-xs text-gray-300">Friends</p>
        </div>
      </div>

      {/* Experience Bar */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-300">Experience</span>
          <span className="text-blue-400">{stats.experience} / {stats.experienceToNext}</span>
        </div>
        <div className="w-full bg-gray-700/50 rounded-full h-2 overflow-hidden">
          <div 
            className="bg-gradient-to-r from-blue-400 to-purple-500 h-full transition-all duration-300 ease-out rounded-full"
            style={{ width: `${experiencePercentage}%` }}
          />
        </div>
      </div>

      {/* Hamster Tap Area */}
      <div className="flex flex-col items-center space-y-4">
        <div 
          className="relative cursor-pointer select-none"
          onClick={handleTap}
          style={{ transform: `scale(${hamsterScale})`, transition: 'transform 0.1s ease-out' }}
        >
          <div className="w-64 h-64 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-8xl shadow-2xl shadow-yellow-500/25 border-4 border-yellow-300/50">
            🐹
            
            {/* Tap Effects */}
            {tapEffects.map(effect => (
              <div
                key={effect.id}
                className="absolute pointer-events-none animate-pulse"
                style={{
                  left: effect.x - 32,
                  top: effect.y - 32,
                  animation: 'fadeUpOut 1s ease-out forwards'
                }}
              >
                <div className="text-2xl font-bold text-yellow-400 drop-shadow-lg">
                  +{stats.tapPower}
                </div>
              </div>
            ))}
          </div>
          
          {stats.energy <= 0 && (
            <div className="absolute inset-0 bg-gray-900/70 rounded-full flex items-center justify-center">
              <div className="text-center">
                <Zap className="w-12 h-12 mx-auto mb-2 text-red-400" />
                <p className="text-red-400 font-semibold">No Energy!</p>
                <p className="text-xs text-gray-300">Wait for recharge</p>
              </div>
            </div>
          )}
        </div>

        <div className="text-center">
          <p className="text-lg font-semibold text-gray-200">Tap the Hamster!</p>
          <p className="text-sm text-gray-400">+{stats.tapPower} coins per tap</p>
        </div>
      </div>

      {/* Energy Bar */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-yellow-400" />
            <span className="text-sm font-medium text-gray-200">Energy</span>
          </div>
          <span className="text-sm text-gray-300">{stats.energy} / {stats.maxEnergy}</span>
        </div>
        <div className="w-full bg-gray-700/50 rounded-full h-3 overflow-hidden">
          <div 
            className={`h-full transition-all duration-300 ease-out rounded-full ${
              energyPercentage > 50 
                ? 'bg-gradient-to-r from-green-400 to-yellow-400' 
                : energyPercentage > 25
                ? 'bg-gradient-to-r from-yellow-400 to-orange-400'
                : 'bg-gradient-to-r from-orange-400 to-red-400'
            }`}
            style={{ width: `${energyPercentage}%` }}
          />
        </div>
        <p className="text-xs text-center text-gray-400">
          Recharges {stats.energyRecharge}/sec
        </p>
      </div>

      {/* Quick Stats */}
      <div className="bg-gradient-to-r from-purple-800/30 to-blue-800/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 text-center text-gray-200">Your Progress</h3>
        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-yellow-400">{stats.totalEarned.toLocaleString()}</p>
            <p className="text-xs text-gray-300">Total Earned</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-green-400">{stats.tapPower}x</p>
            <p className="text-xs text-gray-300">Tap Power</p>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeUpOut {
          0% {
            opacity: 1;
            transform: translateY(0px);
          }
          100% {
            opacity: 0;
            transform: translateY(-50px);
          }
        }
      `}</style>
    </div>
  );
};

export default GameScreen;