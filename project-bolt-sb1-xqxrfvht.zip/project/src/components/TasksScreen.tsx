import React from 'react';
import { useGame } from '../contexts/GameContext';
import { Gift, CheckCircle, Clock, Users, Target, Calendar } from 'lucide-react';

const TasksScreen: React.FC = () => {
  const { tasks, completeTask } = useGame();

  const getTaskIcon = (type: string) => {
    switch (type) {
      case 'daily': return <Calendar className="w-5 h-5" />;
      case 'social': return <Users className="w-5 h-5" />;
      case 'achievement': return <Target className="w-5 h-5" />;
      default: return <Gift className="w-5 h-5" />;
    }
  };

  const getTaskColor = (type: string) => {
    switch (type) {
      case 'daily': return 'from-blue-500 to-blue-600';
      case 'social': return 'from-green-500 to-green-600';
      case 'achievement': return 'from-purple-500 to-purple-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getTaskBorder = (type: string) => {
    switch (type) {
      case 'daily': return 'border-blue-500/30';
      case 'social': return 'border-green-500/30';
      case 'achievement': return 'border-purple-500/30';
      default: return 'border-gray-500/30';
    }
  };

  const completedTasks = tasks.filter(task => task.completed).length;
  const totalRewards = tasks.filter(task => task.completed).reduce((sum, task) => sum + task.reward, 0);
  const availableRewards = tasks.filter(task => task.progress >= task.target && !task.completed).reduce((sum, task) => sum + task.reward, 0);

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl">
          🎁
        </div>
        <h2 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
          Daily Tasks
        </h2>
        <p className="text-gray-300">Complete tasks to earn rewards!</p>
      </div>

      {/* Task Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm border border-blue-500/30 rounded-2xl p-4 text-center">
          <CheckCircle className="w-6 h-6 mx-auto mb-2 text-blue-400" />
          <p className="text-2xl font-bold text-blue-400">{completedTasks}</p>
          <p className="text-xs text-gray-300">Completed</p>
        </div>
        
        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-2xl p-4 text-center">
          <Gift className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-2xl font-bold text-yellow-400">{totalRewards.toLocaleString()}</p>
          <p className="text-xs text-gray-300">Earned</p>
        </div>
        
        <div className="bg-gradient-to-r from-green-500/20 to-teal-500/20 backdrop-blur-sm border border-green-500/30 rounded-2xl p-4 text-center">
          <Clock className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold text-green-400">{availableRewards.toLocaleString()}</p>
          <p className="text-xs text-gray-300">Available</p>
        </div>
      </div>

      {/* Tasks List */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-200">Available Tasks</h3>
        <div className="space-y-4">
          {tasks.map((task) => {
            const progress = Math.min(task.progress, task.target);
            const progressPercentage = (progress / task.target) * 100;
            const isCompleted = task.completed;
            const canClaim = progress >= task.target && !isCompleted;

            return (
              <div
                key={task.id}
                className={`bg-gradient-to-r ${getTaskColor(task.type)}/20 backdrop-blur-sm border ${getTaskBorder(task.type)} rounded-2xl p-4 transition-all duration-200 ${
                  isCompleted ? 'opacity-75' : canClaim ? 'ring-2 ring-green-500/50' : ''
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start space-x-3">
                    <div className={`w-12 h-12 bg-gradient-to-r ${getTaskColor(task.type)} rounded-xl flex items-center justify-center text-white`}>
                      {getTaskIcon(task.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="font-semibold text-gray-200">{task.title}</h4>
                        {isCompleted && (
                          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                        )}
                      </div>
                      <p className="text-sm text-gray-400 mb-2">{task.description}</p>
                      <div className="flex items-center space-x-2">
                        <span className={`text-xs font-medium px-2 py-1 rounded-full bg-gradient-to-r ${getTaskColor(task.type)} text-white`}>
                          {task.type.toUpperCase()}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-yellow-400">{task.reward.toLocaleString()}</p>
                    <p className="text-xs text-gray-400">coins</p>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-300">Progress</span>
                    <span className={`${canClaim ? 'text-green-400' : 'text-gray-400'}`}>
                      {progress} / {task.target}
                    </span>
                  </div>
                  <div className="w-full bg-gray-700/50 rounded-full h-2 overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-300 ease-out rounded-full ${
                        isCompleted 
                          ? 'bg-gradient-to-r from-green-400 to-green-500' 
                          : canClaim
                          ? 'bg-gradient-to-r from-green-400 to-yellow-400'
                          : `bg-gradient-to-r ${getTaskColor(task.type)}`
                      }`}
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                </div>

                {/* Action Button */}
                {isCompleted ? (
                  <div className="w-full py-3 px-4 rounded-xl bg-green-500/20 border border-green-500/50 text-green-400 text-center font-semibold">
                    ✓ Completed
                  </div>
                ) : canClaim ? (
                  <button
                    onClick={() => completeTask(task.id)}
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-green-500 to-yellow-500 hover:from-green-600 hover:to-yellow-600 text-white font-semibold transition-all duration-200 hover:scale-105 flex items-center justify-center space-x-2"
                  >
                    <Gift className="w-4 h-4" />
                    <span>Claim Reward</span>
                  </button>
                ) : (
                  <div className="w-full py-3 px-4 rounded-xl bg-gray-600/50 border border-gray-500/30 text-gray-400 text-center font-semibold">
                    In Progress...
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Reset Timer */}
      <div className="bg-gradient-to-r from-purple-800/30 to-blue-800/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
          <Clock className="w-5 h-5 text-blue-400" />
          <span>Daily Reset</span>
        </h3>
        <div className="text-center space-y-2">
          <p className="text-2xl font-bold text-blue-400">15:42:23</p>
          <p className="text-sm text-gray-300">New tasks available in</p>
        </div>
      </div>

      {/* Task Tips */}
      <div className="bg-gradient-to-r from-gray-800/30 to-gray-700/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
          <span className="text-2xl">💡</span>
          <span>Task Tips</span>
        </h3>
        <div className="space-y-2 text-sm text-gray-300">
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span><strong>Daily Tasks:</strong> Reset every 24 hours</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span><strong>Social Tasks:</strong> Share with friends to complete</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span><strong>Achievements:</strong> One-time rewards for milestones</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Complete all daily tasks for bonus rewards</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TasksScreen;