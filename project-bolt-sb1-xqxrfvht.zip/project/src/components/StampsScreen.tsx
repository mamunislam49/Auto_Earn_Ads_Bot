import React from 'react';
import { useGame } from '../contexts/GameContext';
import { Star, Award, Lock, CheckCircle } from 'lucide-react';

const StampsScreen: React.FC = () => {
  const { stamps, collectStamp } = useGame();

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'from-gray-500 to-gray-600';
      case 'rare': return 'from-blue-500 to-blue-600';
      case 'epic': return 'from-purple-500 to-purple-600';
      case 'legendary': return 'from-yellow-500 to-orange-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getRarityBorder = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-gray-500/50';
      case 'rare': return 'border-blue-500/50';
      case 'epic': return 'border-purple-500/50';
      case 'legendary': return 'border-yellow-500/50';
      default: return 'border-gray-500/50';
    }
  };

  const collectedCount = stamps.filter(stamp => stamp.collected).length;
  const totalRewards = stamps.filter(stamp => stamp.collected).reduce((sum, stamp) => sum + stamp.reward, 0);

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="w-20 h-20 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl">
          ⭐
        </div>
        <h2 className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
          Stamp Collection
        </h2>
        <p className="text-gray-300">Collect rare stamps to earn rewards!</p>
      </div>

      {/* Collection Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm border border-blue-500/30 rounded-2xl p-4 text-center">
          <Award className="w-6 h-6 mx-auto mb-2 text-blue-400" />
          <p className="text-2xl font-bold text-blue-400">{collectedCount}</p>
          <p className="text-xs text-gray-300">Collected</p>
        </div>
        
        <div className="bg-gradient-to-r from-gray-500/20 to-gray-600/20 backdrop-blur-sm border border-gray-500/30 rounded-2xl p-4 text-center">
          <Star className="w-6 h-6 mx-auto mb-2 text-gray-400" />
          <p className="text-2xl font-bold text-gray-400">{stamps.length}</p>
          <p className="text-xs text-gray-300">Total</p>
        </div>
        
        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-2xl p-4 text-center">
          <span className="block w-6 h-6 mx-auto mb-2 text-yellow-400 text-xl">💰</span>
          <p className="text-2xl font-bold text-yellow-400">{totalRewards.toLocaleString()}</p>
          <p className="text-xs text-gray-300">Earned</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-300">Collection Progress</span>
          <span className="text-yellow-400">{collectedCount} / {stamps.length}</span>
        </div>
        <div className="w-full bg-gray-700/50 rounded-full h-2 overflow-hidden">
          <div 
            className="bg-gradient-to-r from-yellow-400 to-orange-500 h-full transition-all duration-300 ease-out rounded-full"
            style={{ width: `${(collectedCount / stamps.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Stamps Grid */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-200">Available Stamps</h3>
        <div className="grid grid-cols-2 gap-4">
          {stamps.map((stamp) => (
            <div
              key={stamp.id}
              className={`relative bg-gradient-to-r ${getRarityColor(stamp.rarity)}/20 backdrop-blur-sm border ${getRarityBorder(stamp.rarity)} rounded-2xl p-4 transition-all duration-200 ${
                stamp.collected ? 'opacity-100' : 'opacity-75 hover:opacity-90'
              }`}
            >
              {/* Rarity Indicator */}
              <div className={`absolute top-2 right-2 w-2 h-2 rounded-full bg-gradient-to-r ${getRarityColor(stamp.rarity)}`} />
              
              {/* Stamp Content */}
              <div className="text-center space-y-3">
                <div className="text-4xl mb-2 relative">
                  {stamp.emoji}
                  {stamp.collected && (
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                  )}
                  {!stamp.collected && (
                    <div className="absolute inset-0 bg-gray-900/70 rounded-lg flex items-center justify-center">
                      <Lock className="w-6 h-6 text-gray-400" />
                    </div>
                  )}
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-200 text-sm">{stamp.name}</h4>
                  <p className="text-xs text-gray-400 mt-1">{stamp.description}</p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-center space-x-1">
                    <span className={`text-xs font-medium px-2 py-1 rounded-full bg-gradient-to-r ${getRarityColor(stamp.rarity)} text-white`}>
                      {stamp.rarity.toUpperCase()}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-center space-x-1">
                    <span className="text-yellow-400 text-lg">💰</span>
                    <span className="text-sm font-semibold text-yellow-400">{stamp.reward.toLocaleString()}</span>
                  </div>
                </div>
                
                {!stamp.collected && (
                  <button
                    onClick={() => collectStamp(stamp.id)}
                    className={`w-full py-2 px-3 rounded-xl text-sm font-semibold transition-all duration-200 bg-gradient-to-r ${getRarityColor(stamp.rarity)} hover:scale-105 text-white`}
                  >
                    Collect Now
                  </button>
                )}
                
                {stamp.collected && (
                  <div className="w-full py-2 px-3 rounded-xl text-sm font-semibold bg-green-500/20 border border-green-500/50 text-green-400">
                    ✓ Collected
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Collection Tips */}
      <div className="bg-gradient-to-r from-purple-800/30 to-blue-800/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
          <span className="text-2xl">💡</span>
          <span>Collection Tips</span>
        </h3>
        <div className="space-y-2 text-sm text-gray-300">
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Complete daily tasks to unlock new stamps</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Invite friends to discover rare stamps</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Higher rarity stamps give bigger rewards</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Collect all stamps in a set for bonus coins</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StampsScreen;