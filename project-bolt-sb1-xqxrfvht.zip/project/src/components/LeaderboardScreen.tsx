import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { Trophy, Medal, Crown, TrendingUp, Users, Coins } from 'lucide-react';

const LeaderboardScreen: React.FC = () => {
  const { getLeaderboard, stats } = useGame();
  const [activeTab, setActiveTab] = useState<'global' | 'friends'>('global');
  
  const leaderboard = getLeaderboard();
  const userRank = leaderboard.findIndex(player => player.name === 'You') + 1;

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-6 h-6 text-yellow-400" />;
      case 2: return <Medal className="w-6 h-6 text-gray-300" />;
      case 3: return <Medal className="w-6 h-6 text-orange-400" />;
      default: return <span className="text-lg font-bold text-gray-400">#{rank}</span>;
    }
  };

  const getRankBg = (rank: number, isUser: boolean = false) => {
    if (isUser) return 'from-blue-600/30 to-purple-600/30 border-blue-500/50';
    switch (rank) {
      case 1: return 'from-yellow-500/20 to-orange-500/20 border-yellow-500/30';
      case 2: return 'from-gray-400/20 to-gray-500/20 border-gray-400/30';
      case 3: return 'from-orange-400/20 to-orange-500/20 border-orange-400/30';
      default: return 'from-gray-700/30 to-gray-800/30 border-white/10';
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="w-20 h-20 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl">
          🏆
        </div>
        <h2 className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
          Leaderboard
        </h2>
        <p className="text-gray-300">See how you stack up!</p>
      </div>

      {/* User Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm border border-blue-500/30 rounded-2xl p-4 text-center">
          <Trophy className="w-6 h-6 mx-auto mb-2 text-blue-400" />
          <p className="text-2xl font-bold text-blue-400">#{userRank}</p>
          <p className="text-xs text-gray-300">Your Rank</p>
        </div>
        
        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-2xl p-4 text-center">
          <Coins className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-2xl font-bold text-yellow-400">{stats.totalEarned.toLocaleString()}</p>
          <p className="text-xs text-gray-300">Total Earned</p>
        </div>
        
        <div className="bg-gradient-to-r from-green-500/20 to-teal-500/20 backdrop-blur-sm border border-green-500/30 rounded-2xl p-4 text-center">
          <TrendingUp className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold text-green-400">{stats.level}</p>
          <p className="text-xs text-gray-300">Level</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-gray-700/30 rounded-2xl p-1">
        <button
          onClick={() => setActiveTab('global')}
          className={`flex-1 py-3 px-4 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center space-x-2 ${
            activeTab === 'global'
              ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Trophy className="w-4 h-4" />
          <span>Global</span>
        </button>
        <button
          onClick={() => setActiveTab('friends')}
          className={`flex-1 py-3 px-4 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center space-x-2 ${
            activeTab === 'friends'
              ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Friends</span>
        </button>
      </div>

      {/* Leaderboard List */}
      <div className="space-y-3">
        {leaderboard.map((player, index) => {
          const rank = index + 1;
          const isUser = player.name === 'You';
          
          return (
            <div
              key={index}
              className={`bg-gradient-to-r ${getRankBg(rank, isUser)} backdrop-blur-sm border rounded-2xl p-4 flex items-center justify-between transition-all duration-200 ${
                isUser ? 'ring-2 ring-blue-500/50' : ''
              }`}
            >
              <div className="flex items-center space-x-4">
                <div className="flex items-center justify-center w-12 h-12">
                  {getRankIcon(rank)}
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-xl">
                    {player.avatar}
                  </div>
                  <div>
                    <p className={`font-semibold ${isUser ? 'text-blue-400' : 'text-gray-200'}`}>
                      {player.name}
                      {isUser && <span className="text-xs text-blue-400 ml-2">(You)</span>}
                    </p>
                    <p className="text-sm text-gray-400">Level {Math.floor(player.coins / 10000) + 1}</p>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <p className="text-lg font-bold text-yellow-400">{player.coins.toLocaleString()}</p>
                <p className="text-xs text-gray-400">coins</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Season Info */}
      <div className="bg-gradient-to-r from-purple-800/30 to-blue-800/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
          <span className="text-2xl">🎯</span>
          <span>Season 1</span>
        </h3>
        <div className="space-y-2 text-sm text-gray-300">
          <div className="flex justify-between">
            <span>Season ends in:</span>
            <span className="text-yellow-400 font-semibold">23 days</span>
          </div>
          <div className="flex justify-between">
            <span>Top 100 reward:</span>
            <span className="text-green-400 font-semibold">10,000 coins</span>
          </div>
          <div className="flex justify-between">
            <span>Top 10 reward:</span>
            <span className="text-purple-400 font-semibold">50,000 coins</span>
          </div>
          <div className="flex justify-between">
            <span>Champion reward:</span>
            <span className="text-yellow-400 font-semibold">100,000 coins</span>
          </div>
        </div>
      </div>

      {/* Climb Tips */}
      <div className="bg-gradient-to-r from-gray-800/30 to-gray-700/30 backdrop-blur-sm border border-white/10 rounded-2xl p-4">
        <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
          <span className="text-2xl">🚀</span>
          <span>Climb Higher</span>
        </h3>
        <div className="space-y-2 text-sm text-gray-300">
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Complete daily tasks for bonus points</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Invite friends to boost your score</span>
          </div>
          <div className="flex items-start space-x-2">
            <span className="text-yellow-400 font-bold">•</span>
            <span>Upgrade your tap power for faster progress</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeaderboardScreen;