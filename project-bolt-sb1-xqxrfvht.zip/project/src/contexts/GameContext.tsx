import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface GameStats {
  coins: number;
  energy: number;
  maxEnergy: number;
  level: number;
  experience: number;
  experienceToNext: number;
  tapPower: number;
  energyRecharge: number;
  friends: number;
  totalEarned: number;
}

interface Stamp {
  id: string;
  name: string;
  description: string;
  emoji: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  collected: boolean;
  reward: number;
}

interface Friend {
  id: string;
  name: string;
  avatar: string;
  coins: number;
  referralBonus: number;
}

interface Task {
  id: string;
  title: string;
  description: string;
  reward: number;
  type: 'daily' | 'achievement' | 'social';
  completed: boolean;
  progress: number;
  target: number;
}

interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  level: number;
  maxLevel: number;
  effect: string;
  icon: string;
}

interface GameContextType {
  stats: GameStats;
  stamps: Stamp[];
  friends: Friend[];
  tasks: Task[];
  upgrades: Upgrade[];
  tap: () => void;
  collectStamp: (stampId: string) => void;
  inviteFriend: (friendData: Omit<Friend, 'id'>) => void;
  completeTask: (taskId: string) => void;
  purchaseUpgrade: (upgradeId: string) => boolean;
  getLeaderboard: () => Array<{ name: string; coins: number; avatar: string }>;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [stats, setStats] = useState<GameStats>({
    coins: 1000,
    energy: 1000,
    maxEnergy: 1000,
    level: 1,
    experience: 0,
    experienceToNext: 1000,
    tapPower: 1,
    energyRecharge: 1,
    friends: 0,
    totalEarned: 1000,
  });

  const [stamps, setStamps] = useState<Stamp[]>([
    {
      id: '1',
      name: 'Golden Hamster',
      description: 'A rare golden hamster stamp',
      emoji: '🐹',
      rarity: 'legendary',
      collected: false,
      reward: 5000,
    },
    {
      id: '2',
      name: 'Energy Bolt',
      description: 'Power up your energy',
      emoji: '⚡',
      rarity: 'rare',
      collected: false,
      reward: 1000,
    },
    {
      id: '3',
      name: 'Coin Master',
      description: 'Master of coins',
      emoji: '🪙',
      rarity: 'epic',
      collected: false,
      reward: 2500,
    },
    {
      id: '4',
      name: 'Friend Finder',
      description: 'Social butterfly',
      emoji: '👫',
      rarity: 'common',
      collected: false,
      reward: 500,
    },
  ]);

  const [friends, setFriends] = useState<Friend[]>([
    {
      id: '1',
      name: 'Alex_Crypto',
      avatar: '👨‍💻',
      coins: 15000,
      referralBonus: 750,
    },
    {
      id: '2',
      name: 'Sarah_Moon',
      avatar: '👩‍🚀',
      coins: 12000,
      referralBonus: 600,
    },
  ]);

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      title: 'Daily Tap Challenge',
      description: 'Tap 1000 times today',
      reward: 500,
      type: 'daily',
      completed: false,
      progress: 0,
      target: 1000,
    },
    {
      id: '2',
      title: 'Invite 5 Friends',
      description: 'Expand your network',
      reward: 2000,
      type: 'social',
      completed: false,
      progress: 2,
      target: 5,
    },
    {
      id: '3',
      title: 'Reach Level 5',
      description: 'Level up your hamster',
      reward: 1500,
      type: 'achievement',
      completed: false,
      progress: 1,
      target: 5,
    },
  ]);

  const [upgrades, setUpgrades] = useState<Upgrade[]>([
    {
      id: '1',
      name: 'Tap Power',
      description: 'Increase coins per tap',
      cost: 1000,
      level: 1,
      maxLevel: 25,
      effect: '+1 coin per tap',
      icon: '👆',
    },
    {
      id: '2',
      name: 'Energy Capacity',
      description: 'Increase maximum energy',
      cost: 1500,
      level: 1,
      maxLevel: 20,
      effect: '+100 max energy',
      icon: '🔋',
    },
    {
      id: '3',
      name: 'Recharge Rate',
      description: 'Faster energy regeneration',
      cost: 2000,
      level: 1,
      maxLevel: 15,
      effect: '+1 energy per second',
      icon: '⚡',
    },
  ]);

  // Energy regeneration
  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        energy: Math.min(prev.maxEnergy, prev.energy + prev.energyRecharge)
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const tap = () => {
    setStats(prev => {
      if (prev.energy <= 0) return prev;

      const newCoins = prev.coins + prev.tapPower;
      const newExperience = prev.experience + 1;
      const newEnergy = prev.energy - 1;
      
      let newLevel = prev.level;
      let newExperienceToNext = prev.experienceToNext;
      
      if (newExperience >= prev.experienceToNext) {
        newLevel += 1;
        newExperienceToNext = newLevel * 1000;
      }

      return {
        ...prev,
        coins: newCoins,
        energy: newEnergy,
        experience: newExperience,
        level: newLevel,
        experienceToNext: newExperienceToNext,
        totalEarned: prev.totalEarned + prev.tapPower,
      };
    });

    // Update daily tap task
    setTasks(prev => prev.map(task => 
      task.id === '1' && !task.completed 
        ? { ...task, progress: Math.min(task.target, task.progress + 1) }
        : task
    ));
  };

  const collectStamp = (stampId: string) => {
    setStamps(prev => prev.map(stamp =>
      stamp.id === stampId ? { ...stamp, collected: true } : stamp
    ));
    
    const stamp = stamps.find(s => s.id === stampId);
    if (stamp) {
      setStats(prev => ({ ...prev, coins: prev.coins + stamp.reward }));
    }
  };

  const inviteFriend = (friendData: Omit<Friend, 'id'>) => {
    const newFriend: Friend = {
      ...friendData,
      id: Date.now().toString(),
    };
    
    setFriends(prev => [...prev, newFriend]);
    setStats(prev => ({
      ...prev,
      friends: prev.friends + 1,
      coins: prev.coins + friendData.referralBonus,
    }));

    // Update friend task
    setTasks(prev => prev.map(task => 
      task.id === '2' && !task.completed 
        ? { ...task, progress: Math.min(task.target, task.progress + 1) }
        : task
    ));
  };

  const completeTask = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (task && task.progress >= task.target && !task.completed) {
      setTasks(prev => prev.map(t =>
        t.id === taskId ? { ...t, completed: true } : t
      ));
      setStats(prev => ({ ...prev, coins: prev.coins + task.reward }));
    }
  };

  const purchaseUpgrade = (upgradeId: string): boolean => {
    const upgrade = upgrades.find(u => u.id === upgradeId);
    if (!upgrade || stats.coins < upgrade.cost || upgrade.level >= upgrade.maxLevel) {
      return false;
    }

    setStats(prev => ({ ...prev, coins: prev.coins - upgrade.cost }));
    
    setUpgrades(prev => prev.map(u => {
      if (u.id === upgradeId) {
        const newLevel = u.level + 1;
        let newCost = Math.floor(u.cost * 1.5);
        
        // Apply upgrade effects
        if (u.id === '1') {
          setStats(prevStats => ({ ...prevStats, tapPower: prevStats.tapPower + 1 }));
        } else if (u.id === '2') {
          setStats(prevStats => ({ ...prevStats, maxEnergy: prevStats.maxEnergy + 100 }));
        } else if (u.id === '3') {
          setStats(prevStats => ({ ...prevStats, energyRecharge: prevStats.energyRecharge + 1 }));
        }

        return { ...u, level: newLevel, cost: newCost };
      }
      return u;
    }));

    return true;
  };

  const getLeaderboard = () => {
    const leaderboard = [
      { name: 'HamsterKing', coins: 50000, avatar: '👑' },
      { name: 'CryptoMaster', coins: 45000, avatar: '💎' },
      { name: 'TapGod', coins: 40000, avatar: '⚡' },
      { name: 'You', coins: stats.totalEarned, avatar: '🐹' },
      { name: 'CoinHunter', coins: 35000, avatar: '🎯' },
    ];

    return leaderboard.sort((a, b) => b.coins - a.coins);
  };

  const value: GameContextType = {
    stats,
    stamps,
    friends,
    tasks,
    upgrades,
    tap,
    collectStamp,
    inviteFriend,
    completeTask,
    purchaseUpgrade,
    getLeaderboard,
  };

  return (
    <GameContext.Provider value={value}>
      {children}
    </GameContext.Provider>
  );
};